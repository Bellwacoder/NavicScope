# NavicScope — Android GNSS monitor

A native Kotlin Android app that reads real satellite status from Android's `GnssStatus` API. It groups satellites by constellation and labels India's NavIC constellation as **NAVIC / IRNSS**.

## Features
- Live satellite count and satellites used in fix
- GPS, GLONASS, Galileo, BeiDou, QZSS, SBAS and NavIC/IRNSS grouping
- SVID, carrier-to-noise density (C/N0), elevation, azimuth and carrier frequency where exposed
- Latitude, longitude, altitude and reported horizontal accuracy
- Dark interface

## Build APK
This workspace does not include the Android SDK or Gradle installation, so a compiled APK cannot be produced here. To build:
1. Install Android Studio (with Android SDK 35).
2. Open this `NavicScope` folder.
3. Let Gradle sync.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 7.0 (API 24). The app asks for location permission because Android requires it for GNSS satellite status.

## Important limitations
- NavIC detection depends on the phone's GNSS chipset, firmware, Android implementation, satellite visibility and current signal conditions.
- The app reports what Android exposes. It cannot enable NavIC if the device does not expose IRNSS measurements.
- Satellite IDs are SVIDs, not satellite counts.
- Location permission is used only for GNSS/location readings; this starter app has no internet permission and does not upload location.
- The app is a practical first version; it does not yet include a sky-plot or signal-strength graph.
