package com.example.navicscope

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.*
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var manager: LocationManager
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var list: LinearLayout
    private lateinit var locationText: TextView
    private val rows = linkedMapOf<String, SatelliteRow>()
    private var lastLocation: Location? = null

    data class SatelliteRow(val constellation: String, val svid: Int, val cn0: Float,
                            val used: Boolean, val elevation: Float, val azimuth: Float,
                            val frequency: Float?)

    private val callback = object : GnssStatus.Callback() {
        override fun onStarted() { runOnUiThread { status.text = "GNSS engine started • waiting for satellites" } }
        override fun onStopped() { runOnUiThread { status.text = "GNSS engine stopped" } }
        override fun onFirstFix(ttffMillis: Int) { runOnUiThread { status.text = "First fix: ${ttffMillis} ms" } }
        override fun onSatelliteStatusChanged(s: GnssStatus) {
            val fresh = linkedMapOf<String, SatelliteRow>()
            var used = 0
            for (i in 0 until s.satelliteCount) {
                val c = constellationName(s.getConstellationType(i))
                val id = s.getSvid(i)
                val row = SatelliteRow(c, id, s.getCn0DbHz(i), s.usedInFix(i),
                    s.getElevationDegrees(i), s.getAzimuthDegrees(i),
                    if (Build.VERSION.SDK_INT >= 26 && s.hasCarrierFrequencyHz(i)) s.getCarrierFrequencyHz(i) / 1_000_000f else null)
                fresh["$c-$id"] = row
                if (row.used) used++
            }
            runOnUiThread {
                rows.clear(); rows.putAll(fresh)
                summary.text = "${s.satelliteCount} satellites visible     •     $used used in fix"
                renderRows()
                status.text = if (s.satelliteCount == 0) "Scanning… keep a clear view of the sky" else "Live satellite data • Android GNSS"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        buildUi()
        if (hasPermission()) startGnss() else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 42)
    }

    private fun buildUi() {
        window.statusBarColor = Color.rgb(10, 14, 25)
        window.navigationBarColor = Color.rgb(10, 14, 25)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(Color.rgb(10, 14, 25))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = text("NAVICSCOPE", 25f, Color.WHITE, true)
        content.addView(title)
        content.addView(text("REAL-TIME GNSS SATELLITE MONITOR", 11f, Color.rgb(120, 174, 255), true))
        status = text("Starting GNSS…", 13f, Color.rgb(170, 190, 220), false)
        status.setPadding(0, 18, 0, 12); content.addView(status)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(22, 30, 48))
        }
        card.addView(text("SATELLITE OVERVIEW", 12f, Color.rgb(130, 160, 205), true))
        summary = text("Waiting for satellite data…", 18f, Color.WHITE, true)
        summary.setPadding(0, 10, 0, 4); card.addView(summary)
        content.addView(card)
        content.addView(text("YOUR LOCATION", 12f, Color.rgb(130, 160, 205), true).apply { setPadding(0, 20, 0, 8) })
        locationText = text("Latitude —    Longitude —\nAccuracy —", 14f, Color.WHITE, false)
        content.addView(locationText)
        content.addView(text("CONSTELLATIONS", 12f, Color.rgb(130, 160, 205), true).apply { setPadding(0, 22, 0, 8) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(text("Note: NavIC appears as IRNSS. Satellite visibility depends on receiver hardware, firmware, location and sky conditions. No IRNSS row means no NavIC satellite was reported in this scan; it does not alone prove hardware incompatibility.", 12f, Color.rgb(150, 165, 190), false).apply { setPadding(0, 20, 0, 20) })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val refresh = Button(this).apply {
            text = "REFRESH LOCATION"
            setOnClickListener { requestOneLocation() }
        }
        root.addView(refresh)
        setContentView(root)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun constellationName(type: Int): String = when (type) {
        GnssStatus.CONSTELLATION_GPS -> "GPS"
        GnssStatus.CONSTELLATION_GLONASS -> "GLONASS"
        GnssStatus.CONSTELLATION_GALILEO -> "GALILEO"
        GnssStatus.CONSTELLATION_BEIDOU -> "BEIDOU"
        GnssStatus.CONSTELLATION_QZSS -> "QZSS"
        GnssStatus.CONSTELLATION_IRNSS -> "NAVIC / IRNSS"
        GnssStatus.CONSTELLATION_SBAS -> "SBAS"
        else -> "UNKNOWN"
    }

    private fun renderRows() {
        list.removeAllViews()
        val groups = rows.values.groupBy { it.constellation }.toSortedMap()
        if (groups.isEmpty()) {
            list.addView(text("No satellites reported yet. Try outdoors with a clear sky.", 14f, Color.LTGRAY, false))
            return
        }
        groups.forEach { (name, satellites) ->
            val navic = name == "NAVIC / IRNSS"
            val header = text("$name  •  ${satellites.size}", 15f,
                if (navic) Color.rgb(80, 220, 170) else Color.rgb(120, 174, 255), true)
            header.setPadding(0, 12, 0, 6); list.addView(header)
            satellites.sortedBy { it.svid }.forEach { sat ->
                val used = if (sat.used) "USED IN FIX" else "VISIBLE"
                val freq = sat.frequency?.let { "  •  ${"%.1f".format(Locale.US, it)} MHz" } ?: ""
                val line = "SVID ${sat.svid}   ${"%.1f".format(Locale.US, sat.cn0)} dB-Hz   $used"
                val sub = "Elevation ${sat.elevation.toInt()}°  •  Azimuth ${sat.azimuth.toInt()}°$freq"
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(12, 9, 12, 9)
                    setBackgroundColor(Color.rgb(18, 25, 40))
                }
                box.addView(text(line, 13f, Color.WHITE, true))
                box.addView(text(sub, 11f, Color.rgb(155, 173, 201), false))
                val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 5
                list.addView(box, lp)
            }
        }
    }

    private fun hasPermission() = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startGnss() {
        if (!hasPermission()) return
        try {
            manager.registerGnssStatusCallback(callback, HandlerCompat.mainLooperHandler())
            requestOneLocation()
        } catch (e: Exception) {
            status.text = "GNSS unavailable: ${e.message ?: "device/OS limitation"}"
        }
    }

    private fun requestOneLocation() {
        if (!hasPermission()) return
        try {
            val provider = when {
                manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> LocationManager.NETWORK_PROVIDER
            }
            manager.requestSingleUpdate(provider, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lastLocation = location
                    locationText.text = "Latitude  ${"%.6f".format(Locale.US, location.latitude)}\nLongitude  ${"%.6f".format(Locale.US, location.longitude)}\nAccuracy  ${"%.1f".format(Locale.US, location.accuracy)} metres\nAltitude  ${if (location.hasAltitude()) "${"%.1f".format(Locale.US, location.altitude)} m" else "—"}"
                }
                @Deprecated("Deprecated")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }, Looper.getMainLooper())
        } catch (_: Exception) { locationText.text = "Location unavailable. Check location settings." }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && hasPermission()) startGnss()
        else status.text = "Location permission is required for live GNSS data."
    }

    override fun onDestroy() {
        super.onDestroy()
        try { manager.unregisterGnssStatusCallback(callback) } catch (_: Exception) {}
    }
}

private object HandlerCompat {
    fun mainLooperHandler() = android.os.Handler(Looper.getMainLooper())
}
